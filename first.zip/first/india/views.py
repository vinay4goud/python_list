import datetime
import re

from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.core.files.storage import default_storage
from django.shortcuts import render, redirect
from india.models import AssetRawData

# Create your views here.
from django.http import HttpResponse


def index(request):
    return render(request, 'index.html', locals())
    # return HttpResponse("Hello, vinsy. You're at the polls index.")


def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username", None)
        psw = request.POST.get('psw', None)
        is_auth = authenticate(request, username=username, password=psw)
        if is_auth:
            login(request, is_auth)
            return redirect('/my-app/')

        else:
            error = f"invalid {username} username and  {psw} password."

    return render(request, "login_view.html", locals())


@login_required(login_url="/login_view/")
def home(request):
    return render(request, "home.html", locals())



def logout_view(request):
    logout_view(request)
    return render(request,"logout.html", locals())


def upload_file(request):
    if request.method == "POST":
        af=request.FILES.get("a_file")
        file_name=default_storage.save(af.name, af)
        file = default_storage.open(file_name, "r")

        list_file = []
        for i in file.readlines():
            dctionary_file = {}
            datez = re.findall("\d{2}/\d{2}/\d{2}|\d{1}/\d{2}/\d{2} \d{1}:\d{2} am| \d{2}:\d{2} am|\d{1}:\d{2} pm|\d{2}:\d{2} pm", i)
            # datez = re.findall('(\d+/\d+/\d+),\s(\d{2}\:\d{2}\s(?:AM|PM|am|pm))')
            # read line if it has date in it
            if datez:

                # date_obj1 = datetime.datetime.strptime(" ".join(datez), '%d/%m/%y %I:%M %p ')
                # split the line
                match = i.split("-", 1)

                # read date from list
                try:

                    date_obj1 = datetime.datetime.strptime(match[0], '%d/%m/%y, %H:%M ')

                except:
                    date_obj1 = datetime.datetime.strptime(match[0], '%d/%m/%y, %I:%M %p ')

                if ':' not in match[1]:
                    matchsecual = []
                    matchsecual.append('none')
                    matchsecual.append(match[1])
                else:

                    # split list into two
                    matchsecual = match[1].split(":", 1)

                # add key and values to empty dictionary
                dctionary_file['datetime'] = date_obj1

                if matchsecual[0]:

                    x = re.findall("[0-9]", matchsecual[0])

                    if len(x) > 0:
                        y = "".join(x)
                        dctionary_file['name'] = y.replace('91', '')
                    else:
                        dctionary_file['name'] = matchsecual[0].strip(" ")

                dctionary_file['content'] = matchsecual[1].rstrip()

                if "1 bhk" in matchsecual[1]:
                    dctionary_file['category'] = "1 bhk"
                elif "2 bhk" in matchsecual[1]:
                    dctionary_file['category'] = "2 bhk"
                elif "3 bhk" in matchsecual[1]:
                    dctionary_file['category'] = "3 bhk"
                else:
                    dctionary_file['category'] = "none"

                # print(dctionary_file)

                # add dictionay to list
                list_file.append(AssetRawData(**dctionary_file))

            print(list_file)
            if len(list_file)>0:
                AssetRawData.objects.bulk_create(list_file)
        return render(request, "upload.html", locals())






