from django.apps import AppConfig


class IndiaConfig(AppConfig):
    name = 'india'
