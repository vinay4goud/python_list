from django.urls import path

from . import views

urlpatterns = [
    # path ('',views.basis,name='basic'),
    path('', views.index, name='index'),
    path('login/',views.login_view,name='login_url'),
    path('my-app/',views.home,name='home'),
    path('logout/',views.logout_view,name='logout_url')
]