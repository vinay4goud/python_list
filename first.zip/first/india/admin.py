#from django.contrib import admin

# Register your models here.

from django.contrib import admin

from .models import Question

admin.site.register(Question)

from .models import asset

admin.site.register(asset)

from .models import category

admin.site.register(category)

from .models import AssetRawData

admin.site.register(AssetRawData)