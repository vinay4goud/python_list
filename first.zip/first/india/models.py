# from django.db import models

# Create your models here.
from django.db import models


class Question(models.Model):
    name = models.CharField(max_length=20)
    age = models.IntegerField()
    date = models.DateTimeField('date published')


class asset(models.Model):
    title = models.CharField(max_length=20)
    discription = models.CharField(max_length=200)
    owner = models.CharField(max_length=30)
    price_range = models.IntegerField()
    is_sold = models.CharField(max_length=10)
    status = models.CharField(max_length=20)

class category(models.Model):
    catagory_choice = (('a','1bhk'), ('b','2bhk'),('c','3bhk'))

    cate = models.CharField(max_length=20,choices=catagory_choice)

class AssetRawData(models.Model):
    datetime = models.DateTimeField()
    name = models.CharField(max_length=20, null=True, blank=True, default=None)
    content = models.CharField(max_length=1500, null=True, blank=True, default=None)
    category = models.CharField(max_length=1500, null=True, blank=True, default=None)

    def __str__(self):
        return f"{self.pk}-{self.name}"


